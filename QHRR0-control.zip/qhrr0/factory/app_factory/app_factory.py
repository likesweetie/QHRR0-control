from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

import yaml

from qhrr0.app.hal.driver.actuators import SPGMITConfig
from qhrr0.app.robot_controller.controller import RobotControllerActuator
from qhrr0.factory.robot_factory.base.robot_base import Robot
from qhrr0.qhrr0_spec import QHRR0

from .app_validation_rules import (
    AppConfigError,
    parse_int,
    reject_removed_dashboard_keys,
    reject_removed_keys as _reject_removed_keys,
    reject_unknown_keys as _reject_unknown_keys,
    require_bool,
    require_float,
    require_int,
    require_key,
    require_list,
    require_mapping,
    require_no_platform_owned_dashboard_keys,
    require_non_empty_string as _require_non_empty_string,
    require_robot_matches_config,
    require_shm_non_empty_string as _require_shm_non_empty_string,
    require_spg_mit_driver as _require_spg_mit_driver,
    optional_float_or_none,
    resolve_zero_set_presets,
    validate_actuator_drivers as _validate_actuator_drivers,
    validate_app_config,
    validate_can_config,
    validate_can_device_config,
    validate_imu_device_config,
    validate_process_config,
    validate_processes_config,
    validate_runtime_safety,
    validate_shm_config,
    validate_spg_mit_driver_config,
    value,
    _non_empty_string,
)


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATHS = PACKAGE_ROOT / "config" / "config_paths.yaml"
DEFAULT_CONTROLLER_CONFIG = PACKAGE_ROOT / "config" / "app_config" / "robot_controller.yaml"


class AppFactory:
    def create_robot_controller_runtime_spec(
        self,
        *,
        controller_config_path: str | Path | None = None,
        config_paths_path: str | Path = DEFAULT_CONFIG_PATHS,
        robot: Robot = QHRR0,
        hardware_requested: bool = False,
        motor_enable_confirmed: bool = False,
        estop_ok: bool = False,
    ) -> dict[str, Any]:
        config_paths = load_config_paths(config_paths_path)
        config = load_robot_controller_config(
            controller_config_path,
            config_paths=config_paths,
            robot=robot,
        )
        options = {
            "hardware_requested": bool(hardware_requested),
            "motor_enable_confirmed": bool(motor_enable_confirmed),
            "estop_ok": bool(estop_ok),
        }
        self.validate_app(robot=robot, config=config, options=options)
        return {
            "controller_kwargs": build_robot_controller_kwargs(config, robot=robot),
            "processes": process_entries(
                config,
                config_paths,
                include_dashboard_runtime=True,
                robot=robot,
            ),
            "config": config,
        }

    def validate_app(
        self,
        *,
        robot: Robot = QHRR0,
        config: Mapping[str, Any],
        options: Mapping[str, Any] | None = None,
    ) -> None:
        validate_app_config(config)
        validate_runtime_safety(config, {} if options is None else options)
        require_robot_matches_config(robot, config)


def load_yaml_mapping(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as fp:
        raw = yaml.safe_load(fp)
    if not isinstance(raw, dict):
        raise AppConfigError(f"{config_path} must contain a YAML mapping")
    return raw


def load_config_paths(path: str | Path = DEFAULT_CONFIG_PATHS) -> dict[str, dict[str, Path]]:
    config_path_value = Path(path)
    raw = load_yaml_mapping(config_path_value)
    base = _project_root_from_config_paths(config_path_value)
    return {
        "configs": {
            **_parse_path_mapping(require_mapping(raw, "app", str(config_path_value)), base),
            **_parse_path_mapping(require_mapping(raw, "robot", str(config_path_value)), base),
        },
        "policy": _parse_path_mapping(require_mapping(raw, "policy", str(config_path_value)), base),
    }


def config_path(paths: Mapping[str, Mapping[str, Path]], key: str) -> Path:
    try:
        return paths["configs"][key]
    except KeyError as exc:
        raise AppConfigError(f"unknown config path key: configs.{key}") from exc


def policy_path(paths: Mapping[str, Mapping[str, Path]], key: str) -> Path:
    try:
        return paths["policy"][key]
    except KeyError as exc:
        raise AppConfigError(f"unknown config path key: policy.{key}") from exc


def load_robot_controller_config(
    path: str | Path | None = None,
    *,
    config_paths: Mapping[str, Mapping[str, Path]] | None = None,
    robot: Robot = QHRR0,
) -> dict[str, Any]:
    paths = load_config_paths() if config_paths is None else config_paths
    controller_path = Path(path).resolve() if path is not None else config_path(paths, "robot_controller")
    raw = load_yaml_mapping(controller_path)
    _reject_removed_keys(raw, {"platform_config", "processes_config"}, "<root>")

    can_device = load_can_device_config(config_path(paths, "can_device"))
    can = parse_can_config(require_mapping(raw, "can", "<root>"), can_device, robot=robot)
    config = {
        "robot": {
            "name": str(robot.name),
            "can_interfaces": tuple(str(item) for item in robot.can_interfaces),
            "actuators": tuple(
                {
                    "name": str(actuator.name),
                    "driver": str(actuator.driver),
                    "can_id": int(actuator.can_id),
                }
                for actuator in robot.actuators
            ),
        },
        "can_device": can_device,
        "runtime": parse_runtime_section(require_mapping(raw, "runtime", "<root>")),
        "hardware": parse_hardware_safety_config(require_mapping(raw, "hardware", "<root>")),
        "safety": parse_safety_policy_config(require_mapping(raw, "safety", "<root>")),
        "state_machine": parse_state_machine_config(require_mapping(raw, "state_machine", "<root>")),
        "robot_controller": parse_robot_controller_core_config(
            require_mapping(raw, "robot_controller", "<root>")
        ),
        "shm": parse_shm_config(
            require_mapping(raw, "shm", "<root>"),
            target_count=len(robot.actuators),
        ),
        "can": can,
        "processes": load_processes_config(config_path(paths, "processes")),
    }
    validate_app_config(config)
    require_robot_matches_config(robot, config)
    return config


def load_can_device_config(path: str | Path) -> dict[str, Any]:
    config_path_value = Path(path).resolve()
    raw = load_yaml_mapping(config_path_value)
    config = {
        "path": config_path_value,
        "imu": parse_imu_device_config(require_mapping(raw, "imu", "<root>")),
        "drivers": parse_driver_configs(require_mapping(raw, "drivers", "<root>")),
    }
    validate_can_device_config(config)
    return config


def parse_runtime_section(raw: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "mode": str(require_key(raw, "mode", "runtime")),
    }


def parse_hardware_safety_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    _reject_unknown_keys(raw, {"allow_real_can"}, "hardware")
    _reject_removed_keys(
        raw,
        {
            "require_manual_arm",
            "require_estop",
            "allow_enable_on_start",
        },
        "hardware",
    )
    return {
        "allow_real_can": require_bool(raw, "allow_real_can", "hardware"),
    }


def parse_safety_policy_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "velocity_damping_kd": require_float(raw, "velocity_damping_kd", "safety"),
        "damping_timeout_s": require_float(raw, "damping_timeout_s", "safety"),
        "command_loss_action": str(require_key(raw, "command_loss_action", "safety")),
        "feedback_stale_action": str(require_key(raw, "feedback_stale_action", "safety")),
    }


def parse_state_machine_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "enable_duration_s": require_float(raw, "enable_duration_s", "state_machine"),
    }


def parse_robot_controller_core_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "name": str(require_key(raw, "name", "robot_controller")),
        "control_hz": require_float(raw, "control_hz", "robot_controller"),
        "shutdown_timeout_s": require_float(raw, "shutdown_timeout_s", "robot_controller"),
    }


def parse_imu_device_config(raw: Mapping[str, Any]) -> dict[str, Any]:
    config = {
        "type": _require_non_empty_string(raw, "type", "imu"),
        "request_id": parse_int(require_key(raw, "request_id", "imu")),
        "quat_id": parse_int(require_key(raw, "quat_id", "imu")),
        "gyro_id": parse_int(require_key(raw, "gyro_id", "imu")),
        "cmd_get_quat": parse_int(require_key(raw, "cmd_get_quat", "imu")),
        "cmd_get_gyro": parse_int(require_key(raw, "cmd_get_gyro", "imu")),
        "cmd_get_all": parse_int(require_key(raw, "cmd_get_all", "imu")),
        "quat_scale": float(require_key(raw, "quat_scale", "imu")),
        "gyro_scale": float(require_key(raw, "gyro_scale", "imu")),
        "normalize_quat": require_bool(raw, "normalize_quat", "imu"),
    }
    validate_imu_device_config(config)
    return config


def parse_driver_configs(raw: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    drivers: dict[str, dict[str, Any]] = {}
    for key, item in raw.items():
        name = _non_empty_string(key, "drivers key")
        if not isinstance(item, dict):
            raise AppConfigError(f"Config key must be a mapping: drivers.{name}")
        drivers[name] = parse_spg_mit_driver_config(item, f"drivers.{name}")
    if not drivers:
        raise AppConfigError("drivers must not be empty")
    return drivers


def parse_spg_mit_driver_config(raw: Mapping[str, Any], path: str) -> dict[str, Any]:
    config = {
        "p_max_rad": float(require_key(raw, "p_max_rad", path)),
        "v_max_rad_s": float(require_key(raw, "v_max_rad_s", path)),
        "kp_max": float(require_key(raw, "kp_max", path)),
        "kd_max": float(require_key(raw, "kd_max", path)),
        "tau_max_nm": float(require_key(raw, "tau_max_nm", path)),
        "feedback_position_max_rad": float(require_key(raw, "feedback_position_max_rad", path)),
        "iq_full_scale_count": float(require_key(raw, "iq_full_scale_count", path)),
        "iq_full_scale_current_a": float(require_key(raw, "iq_full_scale_current_a", path)),
        "set_zero_hold_s": float(require_key(raw, "set_zero_hold_s", path)),
    }
    validate_spg_mit_driver_config(config, path)
    return config


def parse_can_config(
    raw: Mapping[str, Any],
    can_device: Mapping[str, Any],
    *,
    robot: Robot = QHRR0,
) -> dict[str, Any]:
    if "motors" in raw:
        raise AppConfigError("can.motors was removed; motor CAN IDs come from qhrr0_spec")

    daemon_raw = require_mapping(raw, "daemon", "can")
    imu_raw = require_mapping(raw, "imu", "can")
    interface = str(require_key(raw, "interface", "can"))
    if interface not in set(robot.can_interfaces):
        raise AppConfigError("can.interface is not listed in QHRR0 can_interfaces")

    _validate_actuator_drivers(can_device, robot=robot)
    spg = _require_spg_mit_driver(can_device)

    config = {
        "interface": interface,
        "bitrate": require_int(raw, "bitrate", "can"),
        "command_timeout_s": require_float(raw, "command_timeout_s", "can"),
        "bringup_delay_s": require_float(raw, "bringup_delay_s", "can"),
        "daemon": {
            "rx_timeout_s": require_float(daemon_raw, "rx_timeout_s", "can.daemon"),
            "tx_timeout_s": require_float(daemon_raw, "tx_timeout_s", "can.daemon"),
            "join_timeout_s": require_float(daemon_raw, "join_timeout_s", "can.daemon"),
            "max_tx_queue_size": require_int(daemon_raw, "max_tx_queue_size", "can.daemon"),
            "send_block": require_bool(daemon_raw, "send_block", "can.daemon"),
            "send_timeout_s": optional_float_or_none(daemon_raw, "send_timeout_s", "can.daemon"),
            "ipc_socket_path": str(require_key(raw, "daemon_socket", "can")),
            "connect_timeout_s": require_float(daemon_raw, "connect_timeout_s", "can.daemon"),
        },
        "motors": {
            "can_ids": [int(actuator.can_id) for actuator in robot.actuators],
        },
        "imu": {
            "enabled": require_bool(imu_raw, "enabled", "can.imu"),
            "request_all_on_start": require_bool(imu_raw, "request_all_on_start", "can.imu"),
            "request_all_each_tick": require_bool(imu_raw, "request_all_each_tick", "can.imu"),
            "startup_request_count": require_int(imu_raw, "startup_request_count", "can.imu"),
            "startup_request_delay_s": require_float(imu_raw, "startup_request_delay_s", "can.imu"),
        },
        "mit_protocol_range": {
            "position_rad": float(spg["p_max_rad"]),
            "velocity_rad_s": float(spg["v_max_rad_s"]),
            "kp": float(spg["kp_max"]),
            "kd": float(spg["kd_max"]),
            "torque_ff_nm": float(spg["tau_max_nm"]),
            "feedback_position_rad": float(spg["feedback_position_max_rad"]),
        },
    }
    validate_can_config(config)
    return config


def parse_shm_config(raw: Mapping[str, Any], target_count: int) -> dict[str, Any]:
    if "cleanup_stale_on_start" in raw:
        raise AppConfigError("shm.cleanup_stale_on_start was removed; cleanup is controller default behavior")
    if "unlink_on_shutdown" in raw:
        raise AppConfigError("shm.unlink_on_shutdown was removed; unlink is controller default behavior")

    mit_command_raw = require_mapping(raw, "mit_command", "shm")
    aux_command_raw = require_mapping(raw, "aux_command", "shm")
    operator_command_raw = require_mapping(raw, "operator_command", "shm")
    control_state_raw = require_mapping(raw, "control_state", "shm")
    dashboard_state_raw = require_mapping(raw, "dashboard_state", "shm")
    config = {
        "mit_command": {
            "name": _require_shm_non_empty_string(mit_command_raw, "name", "shm.mit_command"),
            "target_count": int(target_count),
        },
        "aux_command": {
            "name": _require_shm_non_empty_string(aux_command_raw, "name", "shm.aux_command"),
            "size_bytes": require_int(aux_command_raw, "size_bytes", "shm.aux_command"),
            "publish_hz": require_float(aux_command_raw, "publish_hz", "shm.aux_command"),
        },
        "operator_command": {
            "name": _require_shm_non_empty_string(operator_command_raw, "name", "shm.operator_command"),
            "size_bytes": require_int(operator_command_raw, "size_bytes", "shm.operator_command"),
        },
        "control_state": {
            "name": _require_shm_non_empty_string(control_state_raw, "name", "shm.control_state"),
            "size_bytes": require_int(control_state_raw, "size_bytes", "shm.control_state"),
            "publish_hz": require_float(control_state_raw, "publish_hz", "shm.control_state"),
        },
        "dashboard_state": {
            "name": _require_shm_non_empty_string(dashboard_state_raw, "name", "shm.dashboard_state"),
            "size_bytes": require_int(dashboard_state_raw, "size_bytes", "shm.dashboard_state"),
            "publish_hz": require_float(dashboard_state_raw, "publish_hz", "shm.dashboard_state"),
        },
    }
    validate_shm_config(config)
    return config


def parse_process_config(item: Any, index: int) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise AppConfigError(f"Config key must be a mapping: processes[{index}]")
    command = require_list(item, "command", f"processes[{index}]")
    if not command:
        raise AppConfigError(f"Config key must not be empty: processes[{index}].command")
    if "env" in item:
        raise AppConfigError("processes[*].env was renamed to processes[*].env_vars")
    env_vars_raw = require_mapping(item, "env_vars", f"processes[{index}]")
    config = {
        "name": str(require_key(item, "name", f"processes[{index}]")),
        "command": [str(part) for part in command],
        "start_order": require_int(item, "start_order", f"processes[{index}]"),
        "stop_order": require_int(item, "stop_order", f"processes[{index}]"),
        "new_terminal": require_bool(item, "new_terminal", f"processes[{index}]"),
        "terminal_command": [
            str(part)
            for part in require_list(item, "terminal_command", f"processes[{index}]")
        ],
        "working_dir": str(require_key(item, "working_dir", f"processes[{index}]")),
        "env_vars": {str(key): str(value) for key, value in env_vars_raw.items()},
    }
    validate_process_config(config)
    return config


def load_processes_config(path: str | Path) -> list[dict[str, Any]]:
    raw = load_yaml_mapping(path)
    configs = [
        parse_process_config(item, index)
        for index, item in enumerate(require_list(raw, "processes", str(path)))
    ]
    validate_processes_config(configs)
    return configs


def build_robot_controller_kwargs(
    config: Mapping[str, Any],
    *,
    robot: Robot = QHRR0,
) -> dict[str, Any]:
    require_robot_matches_config(robot, config)
    spg = value(config, "can_device.drivers.spg_mit")
    imu = value(config, "can_device.imu")
    iq_full_scale_count = float(spg["iq_full_scale_count"])
    if iq_full_scale_count <= 0.0:
        raise AppConfigError("can_device.drivers.spg_mit.iq_full_scale_count must be > 0")

    return {
        "actuators": tuple(
            RobotControllerActuator(
                name=str(actuator.name),
                driver=str(actuator.driver),
                can_id=int(actuator.can_id),
            )
            for actuator in robot.actuators
        ),
        "mit_config": build_mit_config(config),
        "iq_count_to_amp": float(spg["iq_full_scale_current_a"]) / iq_full_scale_count,
        "can_ipc_socket_path": str(value(config, "can.daemon.ipc_socket_path")),
        "can_connect_timeout_s": float(value(config, "can.daemon.connect_timeout_s")),
        "can_command_timeout_s": float(value(config, "can.command_timeout_s")),
        "imu_name": str(robot.imu.name),
        "imu_request_id": int(imu["request_id"]),
        "imu_quat_id": int(imu["quat_id"]),
        "imu_gyro_id": int(imu["gyro_id"]),
        "imu_cmd_get_quat": int(imu["cmd_get_quat"]),
        "imu_cmd_get_gyro": int(imu["cmd_get_gyro"]),
        "imu_cmd_get_all": int(imu["cmd_get_all"]),
        "imu_quat_scale": float(imu["quat_scale"]),
        "imu_gyro_scale": float(imu["gyro_scale"]),
        "imu_normalize_quat": bool(imu["normalize_quat"]),
        "imu_enabled": bool(value(config, "can.imu.enabled")),
        "imu_request_all_on_start": bool(value(config, "can.imu.request_all_on_start")),
        "imu_request_all_each_tick": bool(value(config, "can.imu.request_all_each_tick")),
        "imu_startup_request_count": int(value(config, "can.imu.startup_request_count")),
        "imu_startup_request_delay_s": float(value(config, "can.imu.startup_request_delay_s")),
        "control_hz": float(value(config, "robot_controller.control_hz")),
        "shutdown_timeout_s": float(value(config, "robot_controller.shutdown_timeout_s")),
        "enable_duration_s": float(value(config, "state_machine.enable_duration_s")),
        "velocity_damping_kd": float(value(config, "safety.velocity_damping_kd")),
        "shm_mit_command_name": str(value(config, "shm.mit_command.name")),
        "shm_aux_command_name": str(value(config, "shm.aux_command.name")),
        "shm_aux_command_size_bytes": int(value(config, "shm.aux_command.size_bytes")),
        "shm_operator_command_name": str(value(config, "shm.operator_command.name")),
        "shm_operator_command_size_bytes": int(value(config, "shm.operator_command.size_bytes")),
        "shm_control_state_name": str(value(config, "shm.control_state.name")),
        "shm_control_state_size_bytes": int(value(config, "shm.control_state.size_bytes")),
        "shm_control_state_publish_hz": float(value(config, "shm.control_state.publish_hz")),
        "shm_dashboard_state_name": str(value(config, "shm.dashboard_state.name")),
        "shm_dashboard_state_size_bytes": int(value(config, "shm.dashboard_state.size_bytes")),
        "shm_dashboard_state_publish_hz": float(value(config, "shm.dashboard_state.publish_hz")),
    }


def build_mit_config(config: Mapping[str, Any]) -> SPGMITConfig:
    protocol = value(config, "can.mit_protocol_range")
    return SPGMITConfig(
        p_max=float(protocol["position_rad"]),
        v_max=float(protocol["velocity_rad_s"]),
        kp_max=float(protocol["kp"]),
        kd_max=float(protocol["kd"]),
        tau_max=float(protocol["torque_ff_nm"]),
        feedback_position_max=float(protocol["feedback_position_rad"]),
    )


def process_entries(
    config: Mapping[str, Any],
    config_paths: Mapping[str, Mapping[str, Path]],
    *,
    include_dashboard_runtime: bool,
    robot: Robot = QHRR0,
) -> list[dict[str, Any]]:
    return [
        process_entry(
            process,
            config,
            config_paths,
            include_dashboard_runtime=include_dashboard_runtime,
            robot=robot,
        )
        for process in value(config, "processes")
    ]


def process_entry(
    process: Mapping[str, Any],
    config: Mapping[str, Any],
    config_paths: Mapping[str, Mapping[str, Path]],
    *,
    include_dashboard_runtime: bool,
    robot: Robot = QHRR0,
) -> dict[str, Any]:
    name = str(process["name"])
    env_vars = {str(key): str(item) for key, item in process["env_vars"].items()}
    if name == "can_daemon":
        command = [
            "python3",
            "-m",
            "qhrr0.app.robot_controller.subprocesses.can_daemon.main",
            "--can-interface",
            str(value(config, "can.interface")),
            "--ipc-socket-path",
            str(value(config, "can.daemon.ipc_socket_path")),
            "--rx-timeout-s",
            str(value(config, "can.daemon.rx_timeout_s")),
            "--tx-timeout-s",
            str(value(config, "can.daemon.tx_timeout_s")),
            "--join-timeout-s",
            str(value(config, "can.daemon.join_timeout_s")),
            "--max-tx-queue-size",
            str(value(config, "can.daemon.max_tx_queue_size")),
        ]
        if bool(value(config, "can.daemon.send_block")):
            command.append("--send-block")
        if value(config, "can.daemon.send_timeout_s") is not None:
            command.extend(["--send-timeout-s", str(value(config, "can.daemon.send_timeout_s"))])
        if "--replace-existing-socket" in process["command"]:
            command.append("--replace-existing-socket")
    elif name == "aux_reader":
        command = [
            "python3",
            "-m",
            "qhrr0.app.robot_controller.subprocesses.aux_reader.main",
            "--aux-command-shm-name",
            str(value(config, "shm.aux_command.name")),
            "--joystick-dev",
            _command_arg_value(process["command"], "--joystick-dev", "/dev/input/js0"),
        ]
    elif name == "task_controller":
        try:
            task_control_hz = env_vars.pop("TASK_CONTROL_HZ")
        except KeyError as exc:
            raise AppConfigError("task_controller process requires env_vars.TASK_CONTROL_HZ") from exc
        command = [
            "python3",
            "-m",
            "qhrr0.app.robot_controller.subprocesses.task_controller.main",
            "--policy-runner-config",
            str(config_path(config_paths, "policy_runner")),
            "--policy-list",
            str(policy_path(config_paths, "policy_list")),
            "--pd-config",
            str(policy_path(config_paths, "pd_config")),
            "--robot-name",
            str(value(config, "robot.name")),
            "--can-ids",
            ",".join(str(can_id) for can_id in value(config, "can.motors.can_ids")),
            "--control-state-shm-name",
            str(value(config, "shm.control_state.name")),
            "--aux-command-shm-name",
            str(value(config, "shm.aux_command.name")),
            "--mit-command-shm-name",
            str(value(config, "shm.mit_command.name")),
            "--project-root",
            env_vars.pop("QHRR_PROJECT_ROOT", "."),
            "--control-hz",
            task_control_hz,
        ]
        rate_log_interval_s = env_vars.pop("TASK_RATE_LOG_INTERVAL_S", None)
        if rate_log_interval_s is not None:
            command.extend(["--rate-log-interval-s", rate_log_interval_s])
    elif name == "dashboard":
        command = [
            "python3",
            "-m",
            "qhrr0.app.robot_controller.subprocesses.dashboard.main",
        ]
        if include_dashboard_runtime:
            env_vars["DASHBOARD_RUNTIME_JSON"] = json.dumps(
                build_dashboard_runtime(config, config_paths, robot=robot),
                separators=(",", ":"),
            )
    else:
        raise AppConfigError(f"unsupported process for explicit QHRR0 runtime wiring: {name}")

    return {
        "name": name,
        "command": command,
        "start_order": int(process["start_order"]),
        "stop_order": int(process["stop_order"]),
        "new_terminal": bool(process["new_terminal"]),
        "terminal_command": list(process["terminal_command"]),
        "working_dir": str(process["working_dir"]),
        "env_vars": env_vars,
    }


def build_dashboard_runtime(
    config: Mapping[str, Any],
    config_paths: Mapping[str, Mapping[str, Path]],
    *,
    robot: Robot = QHRR0,
) -> dict[str, Any]:
    raw = load_yaml_mapping(config_path(config_paths, "dashboard"))
    require_no_platform_owned_dashboard_keys(raw)
    reject_removed_dashboard_keys(raw)
    dashboard_config = dict(raw)
    resolve_zero_set_presets(dashboard_config, robot=robot)
    can_monitor = require_mapping(dashboard_config, "can_monitor", "dashboard")
    spg_monitor = require_mapping(dashboard_config, "spg_monitor", "dashboard")
    spg = value(config, "can_device.drivers.spg_mit")
    imu = value(config, "can_device.imu")
    dashboard_config["can"] = {
        "iface": str(value(config, "can.interface")),
        "bitrate": int(value(config, "can.bitrate")),
        "bus_window_s": can_monitor["bus_window_s"],
        "heartbeat_window_s": can_monitor["heartbeat_window_s"],
        "node_timeout_s": can_monitor["node_timeout_s"],
        "stuff_factor": can_monitor["stuff_factor"],
    }
    dashboard_config.setdefault("can_daemon", {})
    dashboard_config["can_daemon"]["ipc_socket_path"] = str(value(config, "can.daemon.ipc_socket_path"))
    dashboard_config.setdefault("robot_controller_state", {})
    dashboard_config["robot_controller_state"]["control_shm_name"] = str(value(config, "shm.control_state.name"))
    dashboard_config["robot_controller_state"]["dashboard_shm_name"] = str(value(config, "shm.dashboard_state.name"))
    dashboard_config["robot_controller_state"]["operator_shm_name"] = str(value(config, "shm.operator_command.name"))
    dashboard_config["robot_controller_state"]["operator_shm_size_bytes"] = int(
        value(config, "shm.operator_command.size_bytes")
    )
    dashboard_config["imu"] = {
        "request_id": int(imu["request_id"]),
        "quat_id": int(imu["quat_id"]),
        "gyro_id": int(imu["gyro_id"]),
        "quat_scale": float(imu["quat_scale"]),
        "gyro_scale": float(imu["gyro_scale"]),
        "normalize_quat": bool(imu["normalize_quat"]),
    }
    dashboard_config["spg"] = {
        "default_mit_poll_hz": spg_monitor["default_mit_poll_hz"],
        "feedback_position_max_rad": spg["feedback_position_max_rad"],
        "iq_full_scale_count": spg["iq_full_scale_count"],
        "iq_full_scale_current_a": spg["iq_full_scale_current_a"],
        "p_max_rad": spg["p_max_rad"],
        "v_max_rad_s": spg["v_max_rad_s"],
        "kp_max": spg["kp_max"],
        "kd_max": spg["kd_max"],
        "tau_max_nm": spg["tau_max_nm"],
    }
    dashboard_config.setdefault("safety", {})
    dashboard_config["safety"]["tx_enabled_by_default"] = False
    dashboard_config["safety"]["allow_actuator_commands"] = False
    dashboard_config["actuators"] = [
        {"name": actuator.name, "can_id": int(actuator.can_id)}
        for actuator in robot.actuators
    ]
    return {
        "dashboard_config": dashboard_config,
        "shutdown_timeout_s": float(value(config, "robot_controller.shutdown_timeout_s")),
        "processes": process_entries(
            config,
            config_paths,
            include_dashboard_runtime=False,
            robot=robot,
        ),
    }


def _project_root_from_config_paths(path: Path) -> Path:
    resolved = path.resolve()
    try:
        return resolved.parents[1]
    except IndexError as exc:
        raise AppConfigError(f"config paths file is too shallow to resolve package root: {path}") from exc


def _parse_path_mapping(raw: Mapping[object, object], base: Path) -> dict[str, Path]:
    paths: dict[str, Path] = {}
    for key, item in raw.items():
        if key is None:
            raise AppConfigError("config path keys must not be empty")
        if item is None:
            raise AppConfigError(f"config path value must not be empty: {key}")
        key_text = str(key)
        item_text = str(item)
        if not key_text:
            raise AppConfigError("config path keys must not be empty")
        if not item_text:
            raise AppConfigError(f"config path value must not be empty: {key_text}")
        candidate = Path(item_text)
        if not candidate.is_absolute():
            candidate = base / candidate
        paths[key_text] = candidate.resolve()
    return paths


def _command_arg_value(command: list[str], name: str, default: str) -> str:
    try:
        index = command.index(name)
    except ValueError:
        return default
    try:
        return str(command[index + 1])
    except IndexError as exc:
        raise AppConfigError(f"process command option {name} requires a value") from exc
