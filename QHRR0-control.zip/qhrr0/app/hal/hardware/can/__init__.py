"""CAN hardware abstractions."""
