from __future__ import annotations


def main() -> None:
    from qhrr0.app.robot_controller.subprocesses.dashboard.backend.app import main as backend_main

    backend_main()


if __name__ == "__main__":
    main()
