from __future__ import annotations

import logging
import math
import time

from enum import IntEnum

from qhrr0.app.hal.can_bus.process_transport import CANProcessTransport
from qhrr0.app.hal.hardware.can.actuator.driver import ActuatorDriver
from qhrr0.app.hal.hardware.can.imu.driver import IMUDriver

from qhrr0.app.hal.driver.actuators import SPGMITConfig, create_spg_actuator_driver
from qhrr0.app.hal.driver.imu import E2BoxIMUProtocol

from qhrr0.app.robot_controller.state_machine import ControllerMode, ControlModeFsm
from qhrr0.app.robot_controller.process_supervisor import ProcessSupervisor
from qhrr0.app.robot_controller.shm.manager import ShmManager
from qhrr0.app.robot_controller.shm import (
    COMMAND_OUTPUT_SOURCE_VALUES,
    MAX_ROBOT_STATE_ACTUATORS,
    OPERATOR_ZERO_TARGET_MAGIC,
    CommandTargetStateC,
    ControlCommandC,
    ControlCommandShm,
    OperatorCommandC,
    OperatorCommandCode,
    OperatorCommandShm,
    RobotStateC,
    RobotStateShm,
)


logger = logging.getLogger(__name__)

class RuntimePhase(IntEnum):
    UNKNOWN = 0
    CREATED = 1
    INIT_SHM = 2
    START_CAN_DAEMON = 3
    BRINGUP_IMU = 4
    START_CHILD_PROCESSES = 5
    RUNNING = 6
    SHUTTING_DOWN = 7
    STOPPED = 8
    ERROR = 9


class RobotControllerActuator:
    def __init__(
        self,
        *,
        name: str,
        driver: str,
        can_id: int,
    ):
        self.name = str(name)
        self.driver = str(driver)
        self.can_id = int(can_id)


class RobotController:
    def __init__(
        self,
        *,
        actuators: tuple[RobotControllerActuator, ...],
        mit_config: SPGMITConfig,
        iq_count_to_amp: float | None,
        can_ipc_socket_path: str,
        can_connect_timeout_s: float,
        can_command_timeout_s: float,
        imu_name: str,
        imu_request_id: int,
        imu_quat_id: int,
        imu_gyro_id: int,
        imu_cmd_get_quat: int,
        imu_cmd_get_gyro: int,
        imu_cmd_get_all: int,
        imu_quat_scale: float,
        imu_gyro_scale: float,
        imu_normalize_quat: bool,
        imu_enabled: bool,
        imu_request_all_on_start: bool,
        imu_request_all_each_tick: bool,
        imu_startup_request_count: int,
        imu_startup_request_delay_s: float,
        control_hz: float,
        shutdown_timeout_s: float,
        enable_duration_s: float,
        velocity_damping_kd: float,
        shm_mit_command_name: str,
        shm_aux_command_name: str,
        shm_aux_command_size_bytes: int,
        shm_operator_command_name: str,
        shm_operator_command_size_bytes: int,
        shm_control_state_name: str,
        shm_control_state_size_bytes: int,
        shm_control_state_publish_hz: float,
        shm_dashboard_state_name: str,
        shm_dashboard_state_size_bytes: int,
        shm_dashboard_state_publish_hz: float,
        process_supervisor: ProcessSupervisor,
    ):
        self._runtime_phase = RuntimePhase.CREATED

        self.controller_actuators = tuple(actuators)
        self.can_command_timeout_s = float(can_command_timeout_s)
        self.imu_enabled = bool(imu_enabled)
        self.imu_request_all_on_start = bool(imu_request_all_on_start)
        self.imu_request_all_each_tick = bool(imu_request_all_each_tick)
        self.imu_startup_request_count = int(imu_startup_request_count)
        self.imu_startup_request_delay_s = float(imu_startup_request_delay_s)
        self.control_hz = float(control_hz)
        self.shutdown_timeout_s = float(shutdown_timeout_s)
        self.velocity_damping_kd = float(velocity_damping_kd)
        self.shm_mit_command_name = str(shm_mit_command_name)
        self.shm_operator_command_name = str(shm_operator_command_name)
        self.shm_control_state_name = str(shm_control_state_name)
        self.shm_dashboard_state_name = str(shm_dashboard_state_name)

        self.can = CANProcessTransport(
            socket_path=str(can_ipc_socket_path),
            connect_timeout_s=float(can_connect_timeout_s),
        )

        ################################################################
        #actuator bring up
        unsupported_drivers = {
            actuator.driver
            for actuator in self.controller_actuators
            if actuator.driver != "spg_mit"
        }
        if unsupported_drivers:
            raise ValueError(f"Unsupported actuator drivers: {sorted(unsupported_drivers)}")
        self.actuators = {
            actuator.can_id: create_spg_actuator_driver(
                name=actuator.name,
                can_id=actuator.can_id,
                mit_config=mit_config,
                feedback_timeout_s=self.can_command_timeout_s,
                feedback_speed_is_motor_side=True,
                iq_count_to_amp=iq_count_to_amp,
            )
            for actuator in self.controller_actuators
        }
        ################################################################

        ################################################################
        #IMU bring up
        self.imu = IMUDriver(
            name=str(imu_name),
            protocol=E2BoxIMUProtocol(
                request_id=int(imu_request_id),
                quat_id=int(imu_quat_id),
                gyro_id=int(imu_gyro_id),
                cmd_get_quat=int(imu_cmd_get_quat),
                cmd_get_gyro=int(imu_cmd_get_gyro),
                cmd_get_all=int(imu_cmd_get_all),
                quat_scale=float(imu_quat_scale),
                gyro_scale=float(imu_gyro_scale),
                normalize_quat=bool(imu_normalize_quat),
            ),
            quat_timeout=self.can_command_timeout_s,
            gyro_timeout=self.can_command_timeout_s,
        )
        ################################################################

        ################################################################
        #shm bring up
        self.shm_manager = ShmManager(
            mit_command_name=self.shm_mit_command_name,
            aux_command_name=shm_aux_command_name,
            aux_command_size_bytes=shm_aux_command_size_bytes,
            operator_command_name=self.shm_operator_command_name,
            operator_command_size_bytes=shm_operator_command_size_bytes,
            control_state_name=self.shm_control_state_name,
            control_state_size_bytes=shm_control_state_size_bytes,
            dashboard_state_name=self.shm_dashboard_state_name,
            dashboard_state_size_bytes=shm_dashboard_state_size_bytes,
        )
        self.control_cmd_shm: ControlCommandShm | None = None
        self.operator_cmd_shm: OperatorCommandShm | None = None
        self.control_state_shm: RobotStateShm | None = None
        self.dashboard_state_shm: RobotStateShm | None = None
        ################################################################

        self.state_machine = ControlModeFsm(
            enable_duration_s=float(enable_duration_s),
        )
        self.processes_supervisor = process_supervisor


        self._last_output_source = "NONE"
        self._last_output_t = 0.0
        self._last_output_targets: tuple[CommandTargetStateC, ...] = ()
        self._control_state_publish_period_s = 1.0 / float(shm_control_state_publish_hz)
        self._dashboard_state_publish_period_s = 1.0 / float(shm_dashboard_state_publish_hz)
        self._last_control_state_publish_t = 0.0
        self._last_dashboard_state_publish_t = 0.0
        self._last_consumed_operator_timestamp_ns: int | None = None
        self._last_ignored_operator_timestamp_ns: int | None = None

        self._running = False

    def start(self) -> None:
        try:
            self.runtime_phase = RuntimePhase.INIT_SHM
            self.shm_manager.cleanup_stale()
            self.shm_manager.create_all()
            self.control_cmd_shm = ControlCommandShm.open(self.shm_mit_command_name)
            self.operator_cmd_shm = OperatorCommandShm.open(self.shm_operator_command_name)
            self.control_state_shm = RobotStateShm.open(self.shm_control_state_name)
            self.dashboard_state_shm = RobotStateShm.open(self.shm_dashboard_state_name)

            self.runtime_phase = RuntimePhase.START_CAN_DAEMON
            self.processes_supervisor.start_by_name("can_daemon")
            self.can.connect()
            self._register_callbacks()

            #bringup_imu()
            self.runtime_phase = RuntimePhase.BRINGUP_IMU
            if self.imu_enabled and self.imu_request_all_on_start:
                for _ in range(self.imu_startup_request_count):
                    self.can.send_frame(self.imu.make_request_all_frame())
                    time.sleep(self.imu_startup_request_delay_s)

            self.runtime_phase = RuntimePhase.START_CHILD_PROCESSES
            self.processes_supervisor.start_all()

            self.runtime_phase = RuntimePhase.RUNNING
            self._running = True

            self._publish_state(force=True)
        except Exception:
            self.runtime_phase = RuntimePhase.ERROR
            self.shutdown()
            raise

    def run(self) -> None:
        control_period_s = 1.0 / self.control_hz
        next_t = time.perf_counter()
        while self._running:
            now = time.perf_counter()
            if now < next_t:
                time.sleep(next_t - now)
            if not self._running:
                break
            self.loop()
            next_t += control_period_s
            now = time.perf_counter()
            if next_t < now:
                next_t = now + control_period_s

    def loop(self) -> RobotStateC:
        now = time.monotonic()
        
        #sending request imu data
        if self.imu_enabled and self.imu_request_all_each_tick:
            self.can.send_frame(self.imu.make_request_all_frame())

        assert self.operator_cmd_shm is not None
        op = self.operator_cmd_shm.read_relaxed()
        op = self._consume_operator_command(op)
        mode = self.state_machine.update(op, now)

        match mode:
            case ControllerMode.ESTOP:
                self._record_output_command("DISABLE", ())
                for actuator in self.actuators.values():
                    self.can.send_frame(actuator.make_disable_frame())
                return self._publish_state()

            case ControllerMode.DISABLED:
                self._record_output_command("DISABLE", ())
                for actuator in self.actuators.values():
                    self.can.send_frame(actuator.make_disable_frame())
                return self._publish_state()

            case ControllerMode.ENABLING:
                self._record_output_command("ENABLE", ())
                for actuator in self.actuators.values():
                    self.can.send_frame(actuator.make_enable_frame())
                return self._publish_state()

            case ControllerMode.ZERO_SETTING:
                self._send_zero_set_all(op)
                return self._publish_state()

            case ControllerMode.DAMPING:
                self._send_damping_all()
                return self._publish_state()

            case ControllerMode.NORMAL:
                assert self.control_cmd_shm is not None
                cmd = self.control_cmd_shm.read_relaxed()
                self._send_policy_command(cmd)
                return self._publish_state()
            
            case _:
                raise RuntimeError(f"Unhandled controller mode: {mode}")


    def request_stop(self) -> None:
        self._running = False

    def shutdown(self) -> None:
        if self.runtime_phase == RuntimePhase.STOPPED:
            return
        self._running = False
        self.runtime_phase = RuntimePhase.SHUTTING_DOWN
        try:
            if self.can.is_connected():
                self._record_output_command("DISABLE", ())
                for actuator in self.actuators.values():
                    self.can.send_frame(actuator.make_disable_frame())
        except Exception as exc:
            logger.warning("Actuator shutdown warning: %s", exc)
        self.processes_supervisor.stop_all(self.shutdown_timeout_s)
        self._publish_state(force=True)

        #close_runtime
        for item in (
            self.control_state_shm,
            self.dashboard_state_shm,
            self.control_cmd_shm,
            self.operator_cmd_shm,
        ):
            if item is not None:
                item.close()
        self.can.close()
        self.shm_manager.close_all()

        self.shm_manager.unlink_all()
        self.runtime_phase = RuntimePhase.STOPPED


    def _register_callbacks(self) -> None:
        for driver in self.actuators.values():
            for can_id in driver.rx_can_ids():
                self.can.register_callback(
                    can_id,
                    lambda frame, driver=driver: self._on_actuator_frame(driver, frame),
                )
        for can_id in self.imu.rx_can_ids():
            self.can.register_callback(can_id, self.imu.on_frame)

    def _on_actuator_frame(self, driver: ActuatorDriver, frame) -> None:
        if self.can.is_recent_tx_echo(frame):
            return
        driver.on_frame(frame)

    def _consume_operator_command(self, command: OperatorCommandC) -> OperatorCommandC:
        try:
            code = OperatorCommandCode(int(command.command))
        except ValueError:
            return command
        if code == OperatorCommandCode.NONE:
            return command

        timestamp_ns = int(command.timestamp_ns)
        if timestamp_ns == self._last_consumed_operator_timestamp_ns:
            if timestamp_ns != self._last_ignored_operator_timestamp_ns:
                logger.warning(
                    "Ignoring already-consumed operator command: code=%s timestamp_ns=%d",
                    code.name,
                    timestamp_ns,
                )
                self._last_ignored_operator_timestamp_ns = timestamp_ns
            released = OperatorCommandC()
            released.timestamp_ns = command.timestamp_ns
            released.command = int(OperatorCommandCode.NONE)
            return released

        self._last_consumed_operator_timestamp_ns = timestamp_ns
        self._last_ignored_operator_timestamp_ns = None
        return command


    def _send_zero_set_all(self, command: OperatorCommandC | None = None) -> None:
        offsets_by_can_id = self._zero_set_offsets_by_can_id(command)
        target_can_ids = sorted(offsets_by_can_id) if offsets_by_can_id else sorted(self.actuators)

        self._record_output_command("ZERO_SET", ())

        for can_id in target_can_ids:
            actuator = self.actuators.get(can_id)
            if actuator is None:
                logger.warning("Skipping zero-set for unknown actuator CAN ID 0x%03X", can_id)
                continue
            offset_deg = float(offsets_by_can_id.get(can_id, 0)) * 0.01
            self.can.send_frame(actuator.make_zero_position_frame(offset_deg=offset_deg))

    @staticmethod
    def _zero_set_offsets_by_can_id(command: OperatorCommandC | None) -> dict[int, int]:
        if command is None:
            return {}
        count = int(command.zero_target_count)
        if count == 0:
            return {}
        if int(command.zero_target_magic) != OPERATOR_ZERO_TARGET_MAGIC:
            raise RuntimeError("Malformed ZERO_SET operator command: invalid zero target magic")
        if count > len(command.zero_targets):
            raise RuntimeError(
                f"Malformed ZERO_SET operator command: target count {count} exceeds "
                f"capacity {len(command.zero_targets)}"
            )
        offsets: dict[int, int] = {}
        for index in range(count):
            target = command.zero_targets[index]
            can_id = int(target.can_id)
            if can_id == 0:
                continue
            offsets[can_id] = int(target.offset_count)
        return offsets


    def _send_damping_all(self) -> None:
        kd = self.velocity_damping_kd
        targets = tuple(
            _command_target_state(
                can_id=can_id,
                p_target_rad=0.0,
                v_target_rad_s=0.0,
                kp=0.0,
                kd=kd,
                tau_target_nm=0.0,
            )
            for can_id in sorted(self.actuators)
        )
        self._record_output_command("DAMPING", targets)
        for can_id in sorted(self.actuators):
            actuator = self.actuators[can_id]
            self.can.send_frame(
                actuator.make_impedance_command_frame(
                    position_rad=0.0,
                    velocity_rad_s=0.0,
                    kp=0.0,
                    kd=kd,
                    torque_ff_nm=0.0,
                )
            )

    def _send_policy_command(self, cmd: ControlCommandC) -> None:
        n = min(int(cmd.num_targets), len(cmd.targets))
        targets: list[CommandTargetStateC] = []
        for index in range(n):
            target = cmd.targets[index]
            actuator = self.actuators.get(int(target.can_id))
            if actuator is None:
                continue
            command_target = _command_target_state(
                can_id=int(target.can_id),
                p_target_rad=float(target.q),
                v_target_rad_s=float(target.dq),
                kp=float(target.kp),
                kd=float(target.kd),
                tau_target_nm=float(target.tau),
            )
            targets.append(command_target)
            self.can.send_frame(
                actuator.make_impedance_command_frame(
                    position_rad=command_target.p_target_rad,
                    velocity_rad_s=command_target.v_target_rad_s,
                    kp=command_target.kp,
                    kd=command_target.kd,
                    torque_ff_nm=command_target.tau_target_nm,
                )
            )
        self._record_output_command("POLICY", tuple(targets))

    def _record_output_command(
        self,
        source: str,
        targets: tuple[CommandTargetStateC, ...],
    ) -> None:
        self._last_output_source = source
        self._last_output_t = time.monotonic()
        self._last_output_targets = targets

    def _publish_state(self, *, force: bool = False) -> RobotStateC:
        state = self._build_robot_state_c()
        now = time.monotonic()
        if (
            self.control_state_shm is not None
            and (force or now - self._last_control_state_publish_t >= self._control_state_publish_period_s)
        ):
            self.control_state_shm.write(state)
            self._last_control_state_publish_t = now
        if (
            self.dashboard_state_shm is not None
            and (force or now - self._last_dashboard_state_publish_t >= self._dashboard_state_publish_period_s)
        ):
            self.dashboard_state_shm.write(state)
            self._last_dashboard_state_publish_t = now
        return state

    def _build_robot_state_c(self) -> RobotStateC:
        now = time.monotonic()
        self.imu.update_fault_flags()
        imu_state = self.imu.get_state()
        imu_comm = self.imu.get_comm_status()

        robot_state = RobotStateC()
        robot_state.timestamp_ns = time.time_ns()
        robot_state.timestamp_monotonic = now
        robot_state.timestamp_unix = time.time()
        robot_state.controller_mode = int(self.state_machine.mode)
        robot_state.actuator_count = min(len(self.actuators), MAX_ROBOT_STATE_ACTUATORS)

        _fill_float_array(
            robot_state.imu.quat_wxyz,
            _quat_xyzw_to_wxyz(imu_state.quat_xyzw),
            (1.0, 0.0, 0.0, 0.0),
        )
        _fill_float_array(
            robot_state.imu.projected_gravity_b,
            getattr(imu_state, "projected_gravity_b", None),
            (0.0, 0.0, -1.0),
        )
        _fill_float_array(
            robot_state.imu.angular_velocity_rad_s,
            imu_state.angular_velocity_rad_s,
            (0.0, 0.0, 0.0),
        )
        robot_state.imu.last_quat_t = float(imu_state.last_quat_t)
        robot_state.imu.last_gyro_t = float(imu_state.last_gyro_t)
        robot_state.imu.quat_online = int(bool(imu_comm["quat"].is_online))
        robot_state.imu.gyro_online = int(bool(imu_comm["gyro"].is_online))
        robot_state.imu.quat_stale = int(bool(imu_comm["quat"].is_stale))
        robot_state.imu.gyro_stale = int(bool(imu_comm["gyro"].is_stale))

        for index, (can_id, driver) in enumerate(sorted(self.actuators.items())):
            if index >= MAX_ROBOT_STATE_ACTUATORS:
                break
            actuator_state = driver.get_state()
            comm = driver.update_fault_flags()
            age_s = (
                None
                if actuator_state.last_feedback_t <= 0.0
                else max(0.0, now - actuator_state.last_feedback_t)
            )
            out = robot_state.actuators[index]
            out.can_id = int(can_id)
            out.position_rad = _float_or_zero(actuator_state.position_rad)
            out.velocity_rad_s = _float_or_zero(actuator_state.velocity_rad_s)
            out.torque_nm = _float_or_zero(actuator_state.torque_nm)
            out.current_a = _float_or_zero(actuator_state.current_a)
            out.temperature_c = _float_or_zero(actuator_state.temperature_c)
            out.fault_code = -1 if actuator_state.fault_code is None else int(actuator_state.fault_code)
            out.is_enabled = -1 if actuator_state.is_enabled is None else int(bool(actuator_state.is_enabled))
            out.last_feedback_t = float(actuator_state.last_feedback_t)
            out.age_s = -1.0 if age_s is None else float(age_s)
            out.online = int(bool(comm.is_online))
            out.stale = int(bool(comm.is_stale))

        command_output = robot_state.command_output
        command_output.timestamp_monotonic = float(self._last_output_t)
        command_output.source = int(COMMAND_OUTPUT_SOURCE_VALUES.get(self._last_output_source, 0))
        command_output.target_count = min(len(self._last_output_targets), MAX_ROBOT_STATE_ACTUATORS)
        for index, item in enumerate(self._last_output_targets[:MAX_ROBOT_STATE_ACTUATORS]):
            out = command_output.targets[index]
            out.can_id = int(item.can_id)
            out.p_target_rad = _float_or_zero(item.p_target_rad)
            out.v_target_rad_s = _float_or_zero(item.v_target_rad_s)
            out.kp = _float_or_zero(item.kp)
            out.kd = _float_or_zero(item.kd)
            out.tau_target_nm = _float_or_zero(item.tau_target_nm)

        return robot_state

    @property
    def runtime_phase(self) -> RuntimePhase:
        return self._runtime_phase

    @runtime_phase.setter
    def runtime_phase(self, new_phase: RuntimePhase) -> None:
        old_phase = getattr(self, "_runtime_phase", None)

        if old_phase == new_phase:
            return

        self._runtime_phase = new_phase

        if old_phase is None:
            logger.info("Controller runtime phase initialized: %s", new_phase.name)
        else:
            logger.info(
                "Controller runtime phase transition: %s -> %s",
                old_phase.name,
                new_phase.name,
            )

def _quat_xyzw_to_wxyz(
    quat_xyzw: tuple[float, float, float, float] | None,
) -> tuple[float, float, float, float] | None:
    if quat_xyzw is None:
        return None
    qx, qy, qz, qw = quat_xyzw
    return qw, qx, qy, qz


def _command_target_state(
    *,
    can_id: int,
    p_target_rad: float,
    v_target_rad_s: float,
    kp: float,
    kd: float,
    tau_target_nm: float,
) -> CommandTargetStateC:
    target = CommandTargetStateC()
    target.can_id = int(can_id)
    target.p_target_rad = float(p_target_rad)
    target.v_target_rad_s = float(v_target_rad_s)
    target.kp = float(kp)
    target.kd = float(kd)
    target.tau_target_nm = float(tau_target_nm)
    return target


def _fill_float_array(target, values, fallback) -> None:
    source = fallback if values is None else values
    for index, value in enumerate(source):
        target[index] = float(value)


def _float_or_zero(value: float | None) -> float:
    if value is None or not math.isfinite(float(value)):
        return 0.0
    return float(value)
