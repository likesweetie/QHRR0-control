"""Aux reader subprocess."""

