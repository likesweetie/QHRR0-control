"""RobotController-managed subprocess entrypoints."""

