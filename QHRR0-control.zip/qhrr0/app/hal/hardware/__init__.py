"""Hardware abstraction implementations."""
