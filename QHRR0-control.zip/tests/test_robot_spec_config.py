from __future__ import annotations

import unittest

from qhrr0.factory.app_factory.app_factory import AppFactory


class RobotSpecConfigTest(unittest.TestCase):
    def test_controller_kwargs_use_qhrr0_static_spec_and_can_device(self) -> None:
        runtime_spec = AppFactory().create_robot_controller_runtime_spec(
            controller_config_path="qhrr0/config/app_config/robot_controller.yaml",
        )

        kwargs = runtime_spec["controller_kwargs"]
        actuators = kwargs["actuators"]

        self.assertEqual([actuator.can_id for actuator in actuators], [0x141, 0x142, 0x143])
        self.assertEqual([actuator.driver for actuator in actuators], ["spg_mit"] * 3)
        self.assertEqual(kwargs["imu_request_id"], 0x221)
        self.assertEqual(kwargs["imu_name"], "e2box_imu")


if __name__ == "__main__":
    unittest.main()
