"""Static robot data classes."""
