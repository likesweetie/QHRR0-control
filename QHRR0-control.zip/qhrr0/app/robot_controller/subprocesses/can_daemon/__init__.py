"""CAN daemon subprocess."""

