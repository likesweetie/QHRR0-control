"""Static robot data factory."""
